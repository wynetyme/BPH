# Run: powershell -ExecutionPolicy Bypass -File .\setup-cursor-skills.ps1
# Review this script and ALL upstream repositories; installed skills and hooks can run code.
param(
    [switch]$SkipPonytail,
    [switch]$SkipUIUX,
    [switch]$SkipRoClicks,
    [switch]$SkipScenario,
    [switch]$SkipTokenSkills
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $projectRoot
foreach ($program in @('node','npx','git')) {
    if (-not (Get-Command $program -ErrorAction SilentlyContinue)) {
        throw "Missing program: $program. Install Node.js 22.20+ and Git before running this script."
    }
}
Write-Host 'Installing curated Cursor Agent Skills; skill dependencies remain third-party code.' -ForegroundColor Cyan

function Add-SkillGroup([string]$repo,[string[]]$skillNames) {
    Write-Host "`nSkills: $repo" -ForegroundColor Cyan
    $arguments = @('--yes','skills','add',$repo,'-a','cursor','-y')
    foreach ($name in $skillNames) { $arguments += @('--skill',$name) }
    & npx @arguments
    if ($LASTEXITCODE -ne 0) { throw "Skill install failed for $repo (exit $LASTEXITCODE). See upstream instructions and retry." }
}

# Narrow selection: fewer irrelevant descriptors saves context and avoids duplicate architecture guidance.
Add-SkillGroup 'TabooHarmony/roblox-brain' @(
    'roblox-luau-types','roblox-luau-patterns','roblox-architecture',
    'roblox-networking','roblox-security','roblox-data','roblox-performance',
    'roblox-gui','roblox-npc-ai','roblox-animation-vfx',
    'roblox-game-design','roblox-monetization','roblox-input'
)
Add-SkillGroup 'EL4CTEO/roblox-skills' @('roblox-luau','roblox-testing','roblox-code-review','roblox-data-stores','roblox-studio-mcp')
Add-SkillGroup 'gamedev-skills/awesome-gamedev-agent-skills' @('tower-defense','card-game','roblox-simulator-economy','game-feel','game-ui-ux')
if (-not $SkipScenario) {
    Add-SkillGroup 'scenario-labs/skills' @('scenario-roblox-expert','scenario-roblox-performance','scenario-roblox-tooling')
}
if (-not $SkipTokenSkills) {
    Add-SkillGroup 'muratcankoylan/Agent-Skills-for-Context-Engineering' @('context-optimization','context-compression','filesystem-context')
    Add-SkillGroup 'bm629/agent-skills' @('token-optimization')
}

if (-not $SkipRoClicks) {
    $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ('roclicks-' + [guid]::NewGuid().ToString('N'))
    try {
        & git clone --depth 1 https://github.com/zriptic/roclicks-skills.git $tmp
        if ($LASTEXITCODE -ne 0) { throw 'Failed to clone RoClicks' }
        foreach ($skill in @('roblox-ui-maker','roblox-vfx')) {
            $src = Join-Path $tmp $skill
            $dest = Join-Path $projectRoot ('.cursor\skills\' + $skill)
            if (-not (Test-Path (Join-Path $src 'SKILL.md'))) { throw "Missing upstream skill $skill" }
            if (Test-Path $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
            Copy-Item -LiteralPath $src -Destination $dest -Recurse -Force
        }
    } finally {
        if (Test-Path $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
    }
}

if (-not $SkipUIUX) {
    & npx --yes ui-ux-pro-max-cli init --ai cursor
    if ($LASTEXITCODE -ne 0) { throw 'UI/UX Pro Max install failed' }
}

if (-not $SkipPonytail) {
    # Ponytail must stay at the cloned location because the installed Cursor hook references it.
    $ponytail = Join-Path $projectRoot '.third_party\ponytail'
    if (-not (Test-Path (Join-Path $ponytail 'scripts\cursor-hooks.js'))) {
        New-Item -ItemType Directory -Path (Split-Path $ponytail) -Force | Out-Null
        & git clone --depth 1 https://github.com/DietrichGebert/ponytail.git $ponytail
        if ($LASTEXITCODE -ne 0) { throw 'Could not clone the official Ponytail repository' }
    }
    $hooksConfig = Join-Path $projectRoot '.cursor\hooks.json'
    if (Test-Path $hooksConfig) {
        $backup = "$hooksConfig.bak-before-ponytail"
        if (-not (Test-Path $backup)) { Copy-Item -LiteralPath $hooksConfig -Destination $backup }
    }
    # IMPORTANT: run from the GAME project root; --project targets $PWD/.cursor/hooks.json.
    $hookInstaller = Join-Path $ponytail 'scripts\cursor-hooks.js'
    & node $hookInstaller install --project
    if ($LASTEXITCODE -ne 0) { throw 'Ponytail Cursor hook installation failed; inspect .cursor/hooks.json and upstream docs.' }
}

Write-Host "`nInstall command finished. Restart Cursor; verify Skills + Hooks, then Studio MCP." -ForegroundColor Green
Write-Host 'Start with prompts/00-verify-environment.txt. Do not assume any tool is working without testing.' -ForegroundColor Green
