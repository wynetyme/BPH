# Durable project state (keep short; update after each Cursor phase)

Last verified update: not started
Current phase: 00 environment verification
Project status: starter kit only — no gameplay code has been implemented
Source-of-truth sync: UNKNOWN (Rojo vs Script Sync)
Studio MCP: UNKNOWN
Relevant installed skills: UNKNOWN until installer completes

## Decisions locked
- Preserve original-style pack opening as a major player-facing feature.
- Both earnable and optional Robux packs, with shared pack reward probabilities for equivalent named packs.
- Source game is a mechanical reference; published presentation must be original/licensed.
- Server-authoritative rolls, inventory, economy, combat, saves.
- Detailed item-level pre-purchase odds, per-player paid restrictions, and idempotent receipts.
- Do not infer new-release weights from old demo values.

## Current acceptance criteria
- Phase 00: tools verified with actual command/tool responses.

## Files and modules changed
- Starter kit only.

## Tests actually run and results
- None yet.

## Unknowns / blockers
- Complete November 2026 release pack tables, wildcard allocation and progression.
- Actual target UX reference footage or screenshots.
- Actual Developer Product IDs, Robux prices, experience universe and ownership.
- Local Cursor/Studio MCP, Rojo and tool installation status.

## Next exact action
Read `prompts/00-verify-environment.txt` and execute its steps.
